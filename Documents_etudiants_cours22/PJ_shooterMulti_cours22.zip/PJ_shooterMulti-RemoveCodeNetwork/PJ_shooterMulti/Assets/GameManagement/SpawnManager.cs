﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SpawnManager : MonoBehaviour {
    public GameObject scoreDisplayerPrefab;
    public GameObject playerRespawnManagerPrefab;
    public GameObject middleOscillatorPrefab;
    public GameObject RedSide;
    public GameObject BlueSide;
    // Use this for initialization
    void Start () {
       
    }
	
	
    
    
}
