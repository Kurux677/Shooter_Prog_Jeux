﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour {
    public Team AssignTeam;
	// Use this for initialization
	

    public Team GetAssignTeam() {
        return AssignTeam;
    }
}
