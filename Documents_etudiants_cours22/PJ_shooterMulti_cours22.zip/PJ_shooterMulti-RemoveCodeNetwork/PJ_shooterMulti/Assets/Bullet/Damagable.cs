﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Damagable  {
    void DealDamage(GameObject from,  int Damage);
}
